from setuptools import setup 

setup(
	name="paqueteCalculos",
	version="1.0",
	description="Calculos matemáticos básicos",
	author="Fabricio",
	author_email="angel.fabriciogonzalez@gmail.com",
	url="",
	packages=["calculosMatematicos"]

	)
